package tm;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;


import vos.Cliente;
import vos.Ingrediente;
import vos.Orden;
import vos.Producto;
import vos.Restaurante;
import vos.Zona;



public class Master {

private static Master instacia;
	
	private static final String CONNECTION_DATA_FILE_NAME_REMOTE = "/conexion.properties";

	private static String connectionDataPath;

	private dao.ConsultaDao consultaDao;


	public static Master darInstancia(String contextPathP) {
		connectionDataPath = contextPathP + CONNECTION_DATA_FILE_NAME_REMOTE;
		instacia = instacia == null ? new Master() : new Master();
		return instacia;
	}

	public Master() 
	{
		consultaDao = new dao.ConsultaDao(connectionDataPath);
		
	}
	
	//  Requerimiento 
	
	//RF1 
	public void registrarUsuario(vos.Usuario pUsuario) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarUsuario(pUsuario);
	}
	//RF2
	public void registrarCliente(Cliente cliente) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarCliente(cliente);
	}
	//RF3
	public void registrarRestaurante(Restaurante restaurante) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarRestaurante(restaurante);
	}
	//RF4
	public void registrarProducto(Producto producto) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarProducto(producto);
	}
	//RF5
	
	public void registrarIngrediente(Ingrediente ingrediente) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarIngrediente(ingrediente);
	}
	//RF6
	public void registrarMenu(vos.Menu menu) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarMenu(menu);
	}
	//RF7
	public void registrarZona(Zona zona) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarZona(zona);
	}
	//RF8
	public void registrarPreferenciaCliente(Cliente cliente) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarPreferencia(cliente);
	}
	//RF9
	public void registrarPedidoProducto(Orden pOrden) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarPedidoDeUnProducto(pOrden);
	}
	//RF10
	public void registrarServicioProducto(Producto producto) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarServicioDeUnProducto(producto);
	}
	
	//Requerimientos de consulta
	
		//RFC1 
	public ArrayList<Producto> consultarProductosServidosEnRotonAndes(Integer IdProducto) throws java.lang.Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarProductosServidosEnRotonAndes(IdProducto);
	}
	//RFC2
	public Zona consultarZona(Integer numeroZona)throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarZona(numeroZona);
	}
	//RFC3
	public ArrayList<Cliente> consultarClientes(Integer idCliente)throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarClientes(idCliente);
	}
	//RFC4
	public ArrayList<Producto> productosMasOfrecidos()throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.productosMasOfrecidos();
	}
	//RFC5
	public ArrayList<Restaurante> consultarRentabilidadRestaurante(Integer idRestaurante)throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarRentabilidadRestaurante(idRestaurante);
	}
	//RFC6
	public ArrayList<Producto> productosMasvendidos()throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.productosMasvendidos();
	}
//iteracion 3
	//Requerimeintos Funcioanales
		//RF11
	public void registrarEquivalenciaIngrediente(Ingrediente solicita, Ingrediente equivalente) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarEquivalenciaIngrediente(solicita, equivalente);
		
	}
		//RF12
	public void registrarEquivalenciaProductos(Producto prod,Producto equivalente) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarEquivalenciaProductos(prod, equivalente);
	}
		//RF13
	public void surtirRestaurante(Restaurante restaurante) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.surtirRestaurante(restaurante);
	}
		//RF14
	public void registrarPedidoProductoEquivalencias(Orden pOrden) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarPedidoProductoEquivalencias(pOrden);
	}
		//RF15
	public void registrarPedidoProductoMesa(Orden orden) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarPedidoProductoMesa(orden);
	}
		//RF16
	public void registrarServicioMesa(Orden pOrden, Producto prod) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.registrarServicioMesa(pOrden, prod);
	}
		//RF17
	public void cancelarPedido(Orden pOrden) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		consultaDao.cancelarPedido(pOrden);
	}
	//Requerimientos Funcionaeles De Consulta
		//RFC7 Administrador 
	public ArrayList<Producto> consultarConsumoClienteAdministrador(int idClienteConsutado)throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarConsumoClienteAdministrador(idClienteConsutado);
	}
		//RFC7 Cliente
	public ArrayList<Producto> consultarConsumoClienteCliente(int idCliente)throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarConsumoClienteCliente(idCliente);
	}
		//RFC8 Administrador
	public ArrayList<Orden> consultarPedidosAdministrador()throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarPedidosAdministrador();
	}
		//RFC8 Restaurante
	public ArrayList<Orden> consultarPedido(int idCliente) throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarPedido(idCliente);
	}
	//Pruebas Iteracion 3
	public Orden consultarOrden(int idOrden)throws Exception
	{
		consultaDao = consultaDao == null ? new dao.ConsultaDao(connectionDataPath) : consultaDao;
		return consultaDao.consultarOrden(idOrden);
	}
}
