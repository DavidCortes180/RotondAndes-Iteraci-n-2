package vos;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonProperty;

public class Restaurante {
	
	private String nombre;
	private String nombreRepresentante;
	private int idRestaurante;
	private String tipoComida;
	private ArrayList<Integer> idZonas= new ArrayList<Integer>();
	private RotonAndesVirtual plataforma;
	private ArrayList<Integer> idMeseros= new ArrayList<Integer>();
	private ArrayList<Integer> idMenus= new ArrayList<Integer>();
	//iteracion 3
	private int capacidadMaxima=20;
	private int productosDisponibles=0;
	
	public Restaurante(@JsonProperty(value="nombre")String nombre, @JsonProperty(value="idRestaurante")int idRestaurante
			,@JsonProperty(value="pNombreRepresentante") String pNombreRepresentante, @JsonProperty(value="pTipoComida")String pTipoComida) {
		super();
		this.setNombre(nombre);
		this.setIdRestaurante(idRestaurante);
		this.setNombreRepresentante(pNombreRepresentante);
		this.setTipoComida(pTipoComida);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	 
	public String getNombreRepresentante() {
		return nombreRepresentante;
	}
	
	public void setNombreRepresentante(String nombreRepresentante) {
		this.nombreRepresentante = nombreRepresentante;
	}
	
	public String getTipoComida() {
		return tipoComida;
	}
	
	public void setTipoComida(String tipoComida) {
		this.tipoComida = tipoComida;
	}

	public int getIdRestaurante() {
		return idRestaurante;
	}

	public void setIdRestaurante(int idRestaurante) {
		this.idRestaurante = idRestaurante;
	}

	public ArrayList<Integer> getZona() {
		return idZonas;
	}

	public void setZona(ArrayList<Integer> pZona) {
		this.idZonas = pZona;
	}

	public RotonAndesVirtual getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(RotonAndesVirtual plataforma) {
		this.plataforma = plataforma;
	}

	public ArrayList<Integer> getMeseros() {
		return idMeseros;
	}

	public void setMeseros(ArrayList<Integer> pMeseros) {
		this.idMeseros = pMeseros;
	}

	public ArrayList<Integer> getMenus() {
		return idMenus;
	}

	public void setMenus(ArrayList<Integer> pMenus) {
		this.idMenus = pMenus;
	}

	public int getProductosDisponibles() {
		return productosDisponibles;
	}

	public void setProductosDisponibles(int productosDisponibles) {
		this.productosDisponibles = productosDisponibles;
	}

	public int getCapacidadMaxima() {
		return capacidadMaxima;
	}

	public void setCapacidadMaxima(int capacidadMaxima) {
		this.capacidadMaxima = capacidadMaxima;
	}
	
	
}
