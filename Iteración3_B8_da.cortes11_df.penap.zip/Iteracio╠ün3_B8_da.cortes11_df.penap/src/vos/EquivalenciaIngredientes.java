package vos;

import org.codehaus.jackson.annotate.JsonProperty;

public class EquivalenciaIngredientes {
	private Ingrediente ingrediente1;
	private Ingrediente ingrediente2;
	public EquivalenciaIngredientes(@JsonProperty(value="ingrediente1")Ingrediente ingrediente1,
			@JsonProperty(value="ingrediente2")Ingrediente ingrediente2) {
		// TODO Auto-generated constructor stub
		this.ingrediente1 = ingrediente1;
		this.ingrediente2 = ingrediente2;
	}
	public Ingrediente getIngrediente1()
	{
		return ingrediente1;
	}
	public Ingrediente getIngrediente2()
	{
		return ingrediente2;
	}
}
