package vos;

public class Pago 
{
	private int idPago;
	private int idCliente;
	private String tipoDePago;
	private int idOrden;
	
	public Pago(int idPago, int idCliente, String tipoDePago, int pIdorden) {
		super();
		this.setIdPago(idPago);
		this.setIdCliente(idCliente);
		this.setTipoDePago(tipoDePago);
		this.setOrden(pIdorden);
	}

	public int getIdPago() {
		return idPago;
	}

	public void setIdPago(int idPago) {
		this.idPago = idPago;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getTipoDePago() {
		return tipoDePago;
	}

	public void setTipoDePago(String tipoDePago) {
		this.tipoDePago = tipoDePago;
	}

	public int getOrden() {
		return idOrden;
	}

	public void setOrden(int orden) {
		idOrden = orden;
	}

	
}
