package vos;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonProperty;

public class Cliente {
	
	private String nombre;
	private int idCliente;
	private RotonAndesVirtual aplicaciones=null;
	private ArrayList<Integer> pedidos= new ArrayList<Integer>();
	private String preferencia;
	
	public Cliente(@JsonProperty(value="nombre")String nombre, @JsonProperty(value="idCliente")int idCliente, @JsonProperty(value="preferencia") String preferencia)
	{
		super();
		this.nombre = nombre;
		this.idCliente = idCliente;
		this.preferencia = preferencia;
	}
	
	public int getIdCliente() {
		return idCliente;
	}
	
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	
	public RotonAndesVirtual getAplicacion() {
		return aplicaciones;
	}
	
	public void setAplicacion(RotonAndesVirtual aplicacion) {
		this.aplicaciones = aplicacion;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	

	public ArrayList<Integer> getPedido() {
		return pedidos;
	}
	public void setPedido(ArrayList<Integer> pedido) {
		this.pedidos = pedido;
	}

	public String getPreferencia() {
		// TODO Auto-generated method stub
		return preferencia;
	}
	
	

	
}
