package vos;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class Ingrediente 
{

	private int idIngrediente;
	
	private String nombreIngrediente;
	
	private String descripcion;
	
	private String traduccion;
	
	private ArrayList<Integer> idIngredientes= new ArrayList<Integer>();
	
	
	public Ingrediente(@JsonProperty(value="idIngrediente")int idIngrediente, @JsonProperty(value="nombreIngrediente")String nombreIngrediente
			,@JsonProperty(value="descripcion") String descripcion, @JsonProperty(value="traduccion")String traduccion) {
		super();
		this.idIngrediente = idIngrediente;
		this.nombreIngrediente = nombreIngrediente;
		this.descripcion = descripcion;
		this.traduccion = traduccion;
	}

	public int getIdIngrediente() {
		return idIngrediente;
	}

	public void setIdIngrediente(int idIngrediente) {
		this.idIngrediente = idIngrediente;
	}

	public String getNombreIngrediente() {
		return nombreIngrediente;
	}

	public void setNombreIngrediente(String nombreIngrediente) {
		this.nombreIngrediente = nombreIngrediente;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getTraduccion() {
		return traduccion;
	}

	public void setTraduccion(String traduccion) {
		this.traduccion = traduccion;
	}

	public ArrayList<Integer> getIdIngredientes() {
		return idIngredientes;
	}

	public void setIdIngredientes(ArrayList<Integer> idIngredientes) {
		this.idIngredientes = idIngredientes;
	}


	
	
	
	
}
