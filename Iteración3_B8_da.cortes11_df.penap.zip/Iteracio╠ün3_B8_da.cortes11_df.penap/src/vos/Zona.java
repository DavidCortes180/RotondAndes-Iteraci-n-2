package vos;

import org.codehaus.jackson.annotate.JsonProperty;

public class Zona 
{

	private int idZona;
	private int capacidad;
	private boolean abierto;
	private boolean apto;
	private String descripcion;
	
	
	public Zona(@JsonProperty(value="idZona")int numeroZona,@JsonProperty(value="capacidad") int capacidad, 
			@JsonProperty(value="abierto")boolean abierto,@JsonProperty(value="apto") boolean apto,
			@JsonProperty(value="descripcion")String descripcion) 
	{
		super();
		this.idZona = numeroZona;
		this.capacidad = capacidad;
		this.abierto = abierto;
		this.apto = apto;
		this.descripcion = descripcion;
	}
	
	public boolean getAbierto()
	{
		return abierto;
	}
	public int getCapacidad() {
		return capacidad;
	}
	
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	
	public int getNumeroZona() {
		return idZona;
	}
	
	public void setAbierto(boolean abierto) {
		this.abierto = abierto;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public void setNumeroZona(int numeroZona) {
		this.idZona = numeroZona;
	}
	
	public boolean  getApto()
	{
		return apto;
	}
	public void setApto(boolean apto) {
		this.apto = apto;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
