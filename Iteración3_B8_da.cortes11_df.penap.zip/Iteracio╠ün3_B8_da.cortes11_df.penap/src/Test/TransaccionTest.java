package Test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import tm.Master;
import vos.Cliente;
import vos.Orden;
import vos.Restaurante;

public class TransaccionTest {
	Master mas = new Master();
	Orden orden1;
	Orden orden2;
	Restaurante restaurante1;
	Restaurante restaurante2;
	Cliente cliente1;
	Cliente cliente2;
	@Before
	public void casosPrueba()
	{
		mas.darInstancia("/Users/mbp15/Universidad/RotonAndes2/WebContent/WEB-INF/ConnectionData");
		//inicio prueba delete
		orden1 = new Orden(201, 12, 2, 2, "C1", 2, 12, null, 1200);
		orden1 = new Orden(202, 13, 21, 21, "C2", 21, 13, null, 1200);
		//inicio prueba update
		restaurante1 = new Restaurante("R1", 201, "Juan", "Comida Rapida");
		restaurante2 = new Restaurante("R2", 202, "Rosa", "Italiana");
		//inicio prueba insert
		cliente1 = new Cliente("Carlos", 201, "Comida Rapida");
		cliente2 = new Cliente("Valentina", 202, "Oriental");
		
	}
	@Test
	public void insert()
	{
		try {
			mas.registrarCliente(cliente1);
			mas.registrarCliente(cliente2);
			String nombreEnSQL1 = mas.consultarClientes(201).get(0).getNombre();
			assertEquals("Carlos", nombreEnSQL1,"No se Registro correctamente");
			String nombreEnSQL2 = mas.consultarClientes(202).get(0).getNombre();
			assertEquals("Valentina", nombreEnSQL2,"No se Registro correctamente");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	@Test
	public void delete()
	{
		try {
			mas.registrarPedidoProducto(orden1);
			mas.registrarPedidoProducto(orden2);
			assertNotEquals(null, mas.consultarOrden(201));
			assertNotEquals(null, mas.consultarOrden(202));
			mas.cancelarPedido(orden1);
			mas.cancelarPedido(orden2);
			assertEquals(null, mas.consultarOrden(201));
			assertEquals(null, mas.consultarOrden(202));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Test
	public void update()
	{
		try {
			assertEquals(0, restaurante1.getProductosDisponibles());
			assertEquals(0, restaurante2.getProductosDisponibles());
			mas.surtirRestaurante(restaurante1);
			mas.surtirRestaurante(restaurante2);
			assertNotEquals(0, restaurante1.getProductosDisponibles());
			assertNotEquals(0, restaurante2.getProductosDisponibles());
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
